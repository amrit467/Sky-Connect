function selectButton(buttonNumber) {
    // Get all buttons
    var buttons = document.querySelectorAll('.button-grp button');

    // Skip removing 'active' class from the first button
    if (buttonNumber !== 1) {
        buttons.forEach(function(button) {
            button.classList.remove('active');
        });
    }

    // Add the 'active' class to the clicked button
    var selectedButton = document.querySelector('.button-grp button:nth-child(' + buttonNumber + ')');
    selectedButton.classList.add('active');
}